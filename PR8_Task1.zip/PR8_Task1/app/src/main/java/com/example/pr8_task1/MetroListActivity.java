package com.example.pr8_task1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MetroListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_metro_list);

        ListView metroStationListView = findViewById(R.id.metroStationListView);

        String[] metroStations = getResources().getStringArray(R.array.metro_stations);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, metroStations);
        metroStationListView.setAdapter(adapter);

        metroStationListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedStation = metroStations[position];
                Intent resultIntent = new Intent();
                resultIntent.putExtra("selectedStation", selectedStation);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}