package com.example.pr8_task3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_SELECT_STATION = 1;
    private static final String PREF_SELECTED_STATION = "selected_station";
    private TextView selectedStationTextView;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        selectedStationTextView = findViewById(R.id.selectedStationTextView);
        Button selectStationButton = findViewById(R.id.selectStationButton);

        selectStationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MetroListActivity.class);
                startActivityForResult(intent, REQUEST_CODE_SELECT_STATION);
            }
        });
        String selectedStation = sharedPreferences.getString(PREF_SELECTED_STATION, "");
        selectedStationTextView.setText(selectedStation);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SELECT_STATION && resultCode == RESULT_OK && data != null) {
            String selectedStation = data.getStringExtra("selectedStation");
            selectedStationTextView.setText(selectedStation);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(PREF_SELECTED_STATION, selectedStation);
            editor.apply();
        }
    }
}

